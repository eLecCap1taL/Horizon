setExecPath("Horizon/src/modules/scheduler/ancient/vip_to_b1")

lockMouse()
wasdCancel()

slot3()
setAngle(8.000000,-180.000000)

src("setpos -390.031250 197.966675 175.000000")

left()

sleep(90)

left(-1)
jump()

sleep(12)

boostLeft(72)
left(-1)
back()

sleep(36)

duck()

sleep(3)

back(-1)
boostStop()
duck(-1)

sleep(1)

jump()
boostRight(105)
right(-1)
forward()

sleep(37)

duck()

sleep(3)

forward(-1)
boostStop()
duck(-1)

sleep(1)

jump()

boostLeft(54)

left(-1)
back()

sleep(37)
duck()

sleep(3)
back(-1)
boostStop()
duck(-1)

sleep(1)

jump()
boostLeft(150)
left(-1)
back(1)

sleep(41)
duck()

sleep(4)
back(-1)
boostStop()
duck(-1)

sleep(1)
jump()
boostRight(150)
right(-1)
forward()

sleep(37)
duck()

sleep(3)
forward(-1)
boostStop()
duck(-1)

sleep(1)
jump()
slot2()
slot1()
boostLeft(57)
left(-1)
back(1)

sleep(40)
back(-1)
boostStop()
turnleft()

sleep(28)
turnleft(-1)

unlockMouse()
