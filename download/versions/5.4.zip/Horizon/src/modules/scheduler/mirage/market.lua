setExecPath("Horizon/src/modules/scheduler/mirage/vip_to_ladder")

lockMouse()
wasdCancel()

setAngle(90,-20.7875)

left()
back()
slot3()

sleep(30)

left(-1)
back(-1)

forward()

sleep(72)

forward(-1)
jump()

sleep(10)
boostRight(200)
sleep(25)
boostStop()
-- sleep(6)
-- boostLeft(200)
-- sleep(17)
-- boostRight(200)
-- sleep(23)



-- src("play sounds/ui/beepclear.vsnd_c")
-- boostStop()
-- duck()
-- jump()
-- boostRight(200)
-- sleep(10)
-- boostStop()
-- -- sleep(5)
-- sleep(32)
-- duck(-1)

-- boostRight(200)

-- sleep(30)

-- boostStop()